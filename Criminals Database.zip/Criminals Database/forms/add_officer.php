<?php
    $connection= new mysqli("localhost","root","","criminal_db");
    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }
    else{
        $_OfficerId = $_POST['off_id'];   
        $_OfficerName = $_POST['off_name'];
        $_Rank = $_POST['rank'];
        $_CaseId = $_POST['case_id'];

        
        $sql_u = "SELECT * FROM officers WHERE off_id='$_OfficerId'";
        $res_u = mysqli_query($connection, $sql_u);
        if (mysqli_num_rows($res_u) > 0) {
            $result = "Sorry... id already taken";
        }else{
            $query = "
            INSERT INTO  officers (off_id,off_name,rank,case_id)
            VALUES ('$_OfficerId', '$_OfficerName', '$_Rank', '$_CaseId') ";
            if($connection->query($query) === TRUE){
                $result =  "Officer is added!";
            }else{
                $result = "Not done";
            }
            
            $connection->close();
            
        }
    }

?>
<!DOCTYPE html>
<html>
<head>
    <title>Result</title>
</head>
<body>

    <div >
        <h2 style="color: white"><?php echo $result; ?></h2> 
    </div>
        <div class="text-center" >      
                <a href="index.html" >Home</a>
                <a href="index.html" >Back</a>
        </div>
</body>
</html>