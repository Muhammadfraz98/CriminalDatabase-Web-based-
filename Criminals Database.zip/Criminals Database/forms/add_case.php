<?php
    $connection= new mysqli("localhost","root","","criminal_db");
    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }
    else{
        $_CaseId = $_POST['case_id'];   
        $_CaseStatus = $_POST['case_status'];
        $_SectionOfLaw = $_POST['section_of_law'];
        $_OfficerId = $_POST['officer_id'];
        $_DateReported = $_POST['date_reported'];

        
        $sql_u = "SELECT * FROM cases WHERE case_id='$_CaseId'";
        $res_u = mysqli_query($connection, $sql_u);
        if (mysqli_num_rows($res_u) > 0) {
            $result = "Sorry... id already taken";
        }else{
            $query = "
            INSERT INTO  cases (case_id,case_status,section_of_law,officer_id, date_reported)
            VALUES ('$_CaseId', '$_CaseStatus', '$_SectionOfLaw', '$_OfficerId', '$_DateReported') ";
            if($connection->query($query) === TRUE){
                $result =  "Case is added!";
            }else{
                $result = "Not done";
            }
            
            $connection->close();
            
        }
    }

?>
<!DOCTYPE html>
<html>
<head>
    <title>Result</title>
</head>
<body>

    <div >
        <h2 style="color: white"><?php echo $result; ?></h2> 
    </div>
        <div class="text-center" >      
                <a href="index.html" >Home</a>
                <a href="index.html" >Back</a>
        </div>
</body>
</html>