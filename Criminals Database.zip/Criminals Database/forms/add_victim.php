<?php
    $connection= new mysqli("localhost","root","","criminal_db");
    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }
    else{
        $_VictimId = $_POST['v_id'];   
        $_FirstName = $_POST['v_firstname'];
        $_LastName = $_POST['v_lastname'];
        $_Sex = $_POST['v_sex'];
        $_Address = $_POST['v_address'];
        $_CaseId = $_POST['case_id'];
        
        $sql_u = "SELECT * FROM victim WHERE v_id='$_VictimId'";
        $res_u = mysqli_query($connection, $sql_u);
        if (mysqli_num_rows($res_u) > 0) {
            $result = "Sorry... id already taken";
        }else{
            $query = "
            INSERT INTO  victim (v_id,firstname,lastname,sex, address, case_id)
            VALUES ('$_VictimId', '$_FirstName', '$_LastName', '$_Sex', '$_Address', '$_CaseId') ";
            if($connection->query($query) === TRUE){
                $result =  "Victim is added!";
            }else{
                $result = "Not done";
            }
            
            $connection->close();
            
        }
    }

?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Victim Result</title>
</head>
<body>

    <div >
        <h2 style="color: white"><?php echo $result; ?></h2> 
    </div>
        <div class="text-center" >      
                <a href="index.html" >Home</a>
                <a href="index.html" >Back</a>
        </div>
</body>
</html>