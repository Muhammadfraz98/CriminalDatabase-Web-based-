<?php
    $connection= new mysqli("localhost","root","","criminal_db");
    if (!$connection)
    {
        die("Connection failed: " . mysqli_connect_error());
    }
    else{  
        $_user1 = $_POST['d_id'];
        $sql_u = "SELECT * FROM accused WHERE accused_id='$_user1'";

        $res_u = mysqli_query($connection, $sql_u);
        
        if (mysqli_num_rows($res_u) == 0) {
            echo  "Sorry... Criminal ID ('$_user1') doest not exists";
        }
        else{
            $sql = "DELETE FROM accused WHERE accused_id='$_user1'";
            if ($connection->query($sql) === TRUE) {
                $result = "Record deleted successfully i.e. '$_user1'";
            }
            else {
                $result =  "Error deleting record: " . $connection->error;
            }
        } 
    	
    }

?>

<!DOCTYPE html>
<html>
<head>
    <title>Criminals Database</title>
</head>
<body>

    <div >
        <h2 style="color: white"><?php echo $result; ?></h2> 
    </div>
        <div class="text-center" >      
                <a href="index.html" >Home</a>
                <a href="index.html" >Back</a>
        </div>
</body>
</html>