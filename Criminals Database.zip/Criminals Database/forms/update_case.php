<?php
    $connection= new mysqli("localhost","root","","criminal_db");
    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }
    else{  
        $_user1 = $_POST['user1'];
        $_user2 = $_POST['newuser1'];
        $sql_u = "SELECT * FROM cases WHERE case_id='$_user1'";

        $res_u = mysqli_query($connection, $sql_u);
        
        if (mysqli_num_rows($res_u) == 0) {
            $result =   "Sorry... Case id ('$_user1') doest not exists";
        }else{
            $sql = "UPDATE cases SET case_id='$_user2' WHERE case_id='$_user1'";
            if ($connection->query($sql) === TRUE) {
                $result = "Record updated successfully.'$_user1' Case has asssigned new ID i.e. '$_user2'";
            } else {
                $result =  "Error updating record: " . $connection->error;
            }
        } 
    	
    }

?>

<!DOCTYPE html>
<html>
<head>
    <title>Criminal Data Base</title>
</head>
<body>
    <div>
        <h2 style="color: white"><?php echo $result; ?></h2> 
    </div>
    <div class="text-center" >      
        <a href="index.html" >Home</a>
        <a href="index.html" >Back</a>
    </div>
</body>
</html>