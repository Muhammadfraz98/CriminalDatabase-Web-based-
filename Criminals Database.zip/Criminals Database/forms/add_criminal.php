<?php
    $connection= new mysqli("localhost","root","","criminal_db");
    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }
    else{
        $_AccusedId = $_POST['accused_id'];   
        $_FirstName = $_POST['firstname'];
        $_LastName = $_POST['lastname'];
        $_Status = $_POST['status'];
        $_Age = $_POST['age'];
        $_Sex = $_POST['sex'];
        $_CNIC = $_POST['cnic'];
        $_CaseId = $_POST['case_id'];
        
        $sql_u = "SELECT * FROM accused WHERE accused_id='$_AccusedId'";
        $res_u = mysqli_query($connection, $sql_u);
        if (mysqli_num_rows($res_u) > 0) {
            $result = "Sorry... id already taken";
        }else{
            $query = "
            INSERT INTO  accused (accused_id,firstname,lastname,status, age,sex, cnic, case_id)
            VALUES ('$_AccusedId', '$_FirstName', '$_LastName', '$_Status', '$_Age', '$_Sex', '$_CNIC', '$_CaseId') ";
            if($connection->query($query) === TRUE){
                $result =  "Criminal is added!";
            }else{
                $result = "Not done";
            }
            
            $connection->close();
            
        }
    }

?>
<!DOCTYPE html>
<html>
<head>
    <title>Result</title>
</head>
<body>

    <div >
        <h2 style="color: white"><?php echo $result; ?></h2> 
    </div>
        <div class="text-center" >      
                <a href="index.html" >Home</a>
                <a href="index.html" >Back</a>
        </div>
</body>
</html>