<?php
    $connection= new mysqli("localhost","root","","criminal_db");
    $result = "";
    if (!$connection)
    {
        die("Connection failed: " . mysqli_connect_error());
    }
    else{ 

        $_user1 = $_POST['user'];
        $_user2 = $_POST['userr'];
        $sql_u = "SELECT * FROM accused WHERE firstname='$_user1' and lastname='$_user2'";


        $res_u = mysqli_query($connection, $sql_u);
        
        if (mysqli_num_rows($res_u) == 0)
        {
            $result =   "Sorry... Criminal name incorrect";
        }
        else
        {
            $result = "'$_user1 $_user2' Exists in database";
        } 

    }

?>

<!DOCTYPE html>
<html>
<head>
    <title>Criminal Database</title>
</head>
<body>

    <div >
        <h2 style="color:white; "><?php echo $result; ?></h2> 
    </div>
        <div class="text-center" >      
                <a href="index.html"  >Home</a>
                <a href="index.html" >Back</a>
        </div>
</body>
</html>